<?php

namespace App\Http\Controllers;

use App\Http\Requests\StoreLoadDetailRequest;
use App\Http\Requests\UpdateLoadDetailRequest;
use App\Models\LoadDetail;

class LoadDetailController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(StoreLoadDetailRequest $request)
    {
        //
    }

    /**
     * Display the specified resource.
     */
    public function show(LoadDetail $loadDetail)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(LoadDetail $loadDetail)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(UpdateLoadDetailRequest $request, LoadDetail $loadDetail)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(LoadDetail $loadDetail)
    {
        //
    }
}
