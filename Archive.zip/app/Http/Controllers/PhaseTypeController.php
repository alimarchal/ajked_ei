<?php

namespace App\Http\Controllers;

use App\Http\Requests\StorePhaseTypeRequest;
use App\Http\Requests\UpdatePhaseTypeRequest;
use App\Models\PhaseType;

class PhaseTypeController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(StorePhaseTypeRequest $request)
    {
        //
    }

    /**
     * Display the specified resource.
     */
    public function show(PhaseType $phaseType)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(PhaseType $phaseType)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(UpdatePhaseTypeRequest $request, PhaseType $phaseType)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(PhaseType $phaseType)
    {
        //
    }
}
